﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace adoDotnet
{
    internal class Program
    {
        static void Main(string[] args)
        {

            try
            {
                string constring = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
                //Sql Connection
                SqlConnection con = new SqlConnection(constring);
                Console.WriteLine("Select any operation to perform: ");
                Console.WriteLine("1) Create table 2) Select 3) Insert 4) Update 5)EmpId ");
                string CRUD = Console.ReadLine();
                con.Open();



                switch (CRUD)
                {
                    case "1":
                        Console.WriteLine("Create a table in database : ");
                        string createquery = Console.ReadLine();
                        SqlCommand createcmd = new SqlCommand(createquery, con);
                        int tablecreated = createcmd.ExecuteNonQuery();
                        Console.WriteLine("Table is created ");
                        goto case "3";

                    case "2":

                        //displaying the output
                        Console.WriteLine("Write Select query to retrieve data from table : ");
                        string selectquery = Console.ReadLine();
                        SqlCommand selectcmd = new SqlCommand(selectquery, con);
                        SqlDataReader dr2 = selectcmd.ExecuteReader();
                        while (dr2.Read())
                        {
                            //Inserted column Names as dr[columnname]
                            int id = Convert.ToInt32(dr2["id"]);
                            string Name = Convert.ToString(dr2["EmpName"]);
                            int Salary = Convert.ToInt32(dr2["EmpSalary"]);
                            Console.WriteLine(id + " " + Name + " " + Salary);
                        }
                        break;
                    case "3":
                        Console.WriteLine("Write Insert query to insert values in the table : ");
                        Console.WriteLine("Enter how many rows to add : ");
                        int r = Convert.ToInt32(Console.ReadLine());
                        for (var i = 0; i < r; i++)
                        {
                            Console.Write("Enter Employee id :");
                            int empid = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Enter Employee Name :");
                            string empname = Console.ReadLine();
                            Console.Write("Enter Employee Salary");
                            int empsalary = Convert.ToInt32(Console.ReadLine());
                            string insertquery = String.Format("insert into Employee values({0},'{1}',{2})", empid, empname, empsalary);
                            SqlCommand insertcmd = new SqlCommand(insertquery, con);
                            int rowsAdded = insertcmd.ExecuteNonQuery();
                        }
                        Console.WriteLine(r + " Rows are Effected ");
                        goto case "2";



                    case "4":
                        Console.WriteLine("write update query to update data in table : ");
                        string updatequery = Console.ReadLine();
                        SqlCommand updatecmd = new SqlCommand(updatequery, con);
                        int updatecreated = updatecmd.ExecuteNonQuery();
                        goto case "2";

                    case "5":
                        Console.WriteLine("Enter Employee id : ");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        string procedure = "EmployeeRecord";
                        SqlCommand storedcmd = new SqlCommand(procedure, con);
                        SqlParameter param = storedcmd.Parameters.Add(new SqlParameter("@id", System.Data.SqlDbType.Int));
                        storedcmd.CommandType = System.Data.CommandType.StoredProcedure;
                        SqlDataReader dr3 = storedcmd.ExecuteReader();
                        while (dr3.Read())
                        {
                            //Inserted column Names as dr[columnname]
                            int id = Convert.ToInt32(dr3["id"]);
                            string Name = Convert.ToString(dr3["EmpName"]);
                            int Salary = Convert.ToInt32(dr3["EmpSalary"]);
                            Console.WriteLine(id + " " + Name + " " + Salary);
                        }
                      goto case "2";


                }
            }


            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadKey();
        }
    }
 }
    



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace webApiCore.Models
{
  
        [Table("UserTable")]
        public class User
        {
            [Key]
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            [Column("UID")]
            public int Id { get; set; }
            [Required]
            [StringLength(50)]
            public string FirstName { get; set; }

            [StringLength(50)]
            public string LastName { get; set; }

            [Required]
            [Range(typeof(int), "18", "60")]
            public int Age { get; set; }

            [Required]
            [StringLength(60)]
            public string Email { get; set; }

            [StringLength(10)]
            [Required]
            public string MobileNumber { get; set; }

            [Required]
            [StringLength(10)]
            public string Password { get; set; }

        }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using webApiCore.Models;
using Microsoft.EntityFrameworkCore;
namespace webApiCore.Data
{
    public class userDbContext : DbContext
    {
        
     

        public userDbContext(DbContextOptions<userDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
         public DbSet<User> UserTable { get; set; }
    }
}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using webApiCore.Models;
using webApiCore.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace webApiCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IDataRepository dataRepository;
        public UserController(IDataRepository _dataRepository)
        {
            dataRepository = _dataRepository;
        }

        

        [HttpGet]
        [Route("GetUsers")]
        public async Task<IActionResult> GetUsers()
        {
            try
            {
                var users = await dataRepository.GetUsers();
                if (users == null)
                {
                    return NotFound();
                }

                return Ok(users);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetUser")]
        public async Task<IActionResult> GetUser(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                var user = await dataRepository.GetUser(id);

                if (user == null)
                {
                    return NotFound();
                }

                return Ok(user);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> AddUser([FromBody] User model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var postId = await dataRepository.AddUser(model);
                    if (postId > 0)
                    {
                        return Ok(model);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpDelete]
        [Route("DeleteUser")]
        public async Task<IActionResult> DeleteUser(int Id)
        {
            
            User user = await dataRepository.GetUser(Id);
            try
            {
               var result = await dataRepository.DeleteUser(user.Id);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok("Record is deleted ..!");
            }
            catch (Exception)
            {

                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateUser")]
        public async Task<IActionResult> UpdateUser(int id,[FromBody] User model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await dataRepository.UpdateUser(model);

                    return Ok(model);
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webApiCore.Models;

namespace webApiCore.Repository
{
    public interface IDataRepository
    {
        Task<List<User>> GetUsers();

        Task<User> GetUser(int?Id);

        Task<int> AddUser(User user);

        Task<int> DeleteUser(int? Id);

        Task UpdateUser(User user);
    }
}

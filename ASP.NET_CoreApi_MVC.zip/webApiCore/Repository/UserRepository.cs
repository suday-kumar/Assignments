﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webApiCore.Models;
using webApiCore.Data;
using Microsoft.EntityFrameworkCore;

namespace webApiCore.Repository
{
    public class UserRepository : IDataRepository
    {
        userDbContext db;
        public UserRepository(userDbContext _db)
        {
            db = _db;
        }

      

        public async Task<List<User>> GetUsers()
        {
            if (db != null)
            {
                return await (from u in db.UserTable
                            
                          
                              select new User
                              {
                                  Id = u.Id,
                                  FirstName = u.FirstName,
                                  LastName = u.LastName,
                                  Age = u.Age,
                                  Email = u.Email,
                                  MobileNumber = u.MobileNumber,
                                  Password = u.Password,
                              }).ToListAsync();
            }

            return null;
        }

        public async Task<User> GetUser(int? userId)
        {
            if (db != null)
            {
                return await (from u in db.UserTable
                             
                              where u.Id  == userId
                              select new User
                              {
                                  Id=u.Id,
                                  FirstName=u.FirstName,
                                  LastName=u.LastName,
                                  Age=u.Age,
                                  Email=u.Email,
                                  MobileNumber=u.MobileNumber,
                                  Password=u.Password,
                                  
                              }).FirstOrDefaultAsync();
            }

            return null;
        }

        public async Task<int> AddUser(User user)
        {
            if (db != null)
            {
                await db.UserTable.AddAsync(user);
                await db.SaveChangesAsync();

                return user.Id;
            }

            return 0;
        }

        public async Task<int> DeleteUser(int? id)
        {
            int result = 0;

            if (db != null)
            {
                //Find the post for specific post id
                var user = await db.UserTable.FirstOrDefaultAsync(x => x.Id == id);

                if (user != null)
                {
                    //Delete that post
                    db.UserTable.Remove(user);

                    //Commit the transaction
                    result = await db.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }


        public async Task UpdateUser(User user)
        {
            if (db != null)
            {
                //Delete that post
                db.UserTable.Update(user);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
    }
}


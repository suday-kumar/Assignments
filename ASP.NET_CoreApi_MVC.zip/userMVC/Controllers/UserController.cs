﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using userMVC.Models;

namespace userMVC.Controllers
{
    public class UserController : Controller
    {
        HttpClientHandler clientHandler = new HttpClientHandler();
        // GET: UserController
        public async Task<ActionResult> Index()
        {
            List<UserViewModel> users = new List<UserViewModel>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44313/api/user/getusers"))
                {
                    string apiResponse
                        = await response.Content.ReadAsStringAsync();
                    users = JsonConvert.DeserializeObject
                                    <List<UserViewModel>>(apiResponse);
                }
            }
            return View(users);
        }

        // GET: UserController/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                UserViewModel newUser = new UserViewModel();
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("https://localhost:44313/api/user/adduser", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        newUser = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);
                    }

                }
                return RedirectToAction("Index");

            }

            return View(user);

        }
        public async Task<ActionResult> Details(int id)
        {
            UserViewModel user = new UserViewModel();
            using (var httpClient = new HttpClient())

            {
                using (var response = await httpClient.GetAsync("https://localhost:44313/api/User/GetUser?id=" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);
                }
            }
            return View(user);
        }

        public async Task<ActionResult> Edit(int id)
        {
            UserViewModel user = new UserViewModel();
            using (var httpClient = new HttpClient())
            {

                using (var response
                     = await httpClient.GetAsync("https://localhost:44313/api/User/GetUser?id=" + id))
                {
                    string apiResponse
                        = await response.Content.ReadAsStringAsync();
                    user
                        = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);
                }
            }
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(UserViewModel user)
        {
            UserViewModel updatedUser = new UserViewModel();
          
            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(user.Id.ToString()), "Id");
                content.Add(new StringContent(user.FirstName), "FirstName");
                content.Add(new StringContent(user.LastName), "LastName");
                content.Add(new StringContent(user.Age.ToString()), "Age");
                content.Add(new StringContent(user.Email), "Email");
                content.Add(new StringContent(user.MobileNumber), "MobileNumber");
                content.Add(new StringContent(user.Password), "Password");
                content.Add(new StringContent(user.ConfirmPassword), "ConfirmPassword");
                StringContent Content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");

                using (var response =await httpClient.PutAsync("https://localhost:44313/api/User/UpdateUser", Content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    updatedUser = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);
                }
            }
            return RedirectToAction("Index");
        }

 //// GET: UserController/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            UserViewModel user = new UserViewModel();
            using (var httpClient = new HttpClient())
            {
                // StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");

                using (var response
                     = await httpClient.GetAsync("https://localhost:44313/api/User/GetUser?id=" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<UserViewModel>(apiResponse);
                }
            }
            return View(user);
        }

        ////// POST: UserController/Delete/5

        [HttpPost]
        public async Task<IActionResult> Delete(UserViewModel user)
        {
           
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("https://localhost:44313/api/User/DeleteUser?Id=" + user.Id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }

            }

            return RedirectToAction("Index");
        }
    }
}
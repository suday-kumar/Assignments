﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuctionMVCCore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AuctionMVCCore.Controllers
{
    public class PlayerController : Controller
    {
        private readonly PlayerContext _context;

        public PlayerController(PlayerContext context)
        {
            _context = context;
        }
        // GET: PlayerController
        public async Task<IActionResult> Index()
        {
            var p1 = await _context.players.ToListAsync();
            return View(p1);
        }

        public async Task<IActionResult> Edit(int? playerId)
        {
            ViewBag.PageName = playerId == null ? "Create Employee" : "Edit Employee";
            ViewBag.IsEdit = playerId == null ? false : true;
            if (playerId == null)
            {
                return View();
            }
            else
            {
                var player1 = await _context.players.FindAsync(playerId);

                if (player1 == null)
                {
                    return NotFound();
                }
                return View(player1);
            }
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int PlayerId, [Bind("PlayerId,Name,Age,Role,Country,price")]Player PlayerData)
        {
            bool IsPlayerExist = false;

            Player p1 = await _context.players.FindAsync(PlayerId);

            if (p1 != null)
            {
                IsPlayerExist = true;
            }
            else
            {
                p1 = new Player();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    p1.Name = PlayerData.Name;
                    p1.Age= PlayerData.Age;
                    p1.Role = PlayerData.Role;
                   p1.Country= PlayerData.Country;
                    p1.price = PlayerData.price;

                    if (IsPlayerExist)
                    {
                        _context.Update(p1);
                    }
                    else
                    {
                        _context.Add(p1);
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(nameof(Index));
        }

        //public async Task<IActionResult> Edit(int? PlayerId)
        //{
        //    ViewBag.PageName = PlayerId == null ? "Create Employee" : "Edit Employee";
        //    ViewBag.IsEdit = PlayerId == null ? false : true;
        //    if (PlayerId == null)
        //    {
        //        return View();
        //    }
        //    else
        //    {
        //        var player1 = await _context.players.FindAsync(PlayerId);

        //        if (player1 == null)
        //        {
        //            return NotFound();
        //        }
        //        return View(player1);
        //    }
        //}




        public async Task<IActionResult> Details(int? PlayerId)
        {
            if (PlayerId == null)
            {
                return NotFound();
            }
            var player = await _context.players.FirstOrDefaultAsync(m => m.PlayerId == PlayerId);
            if (player == null)
            {
                return NotFound();
            }
            return View(player);
        }
        // GET: PlayerController/Edit/5
        public async Task<IActionResult> Delete(int? PlayerId)
        {
            if (PlayerId == null)
            {
                return NotFound();
            }
            var player = await _context.players.FirstOrDefaultAsync(m => m.PlayerId == PlayerId);

            return View(player);
        }

        // POST: Employees/Delete/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int PlayerId)
        {
            var player = await _context.players.FindAsync(PlayerId);
            _context.players.Remove(player);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

    }





    
     
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqAssignment
{
    public class Employee
    {
     public int EmployeeID { get; set; }

        public string FirstName { get; set; }    
        public string LastName { get; set; }    
        public string Title { get; set; }    
        public DateTime DOB { get; set; }    
        public DateTime DOJ { get; set; }    
        public string City { get; set; }

        internal class Program
        {
            public static List<Employee> empList = new List<Employee>
{
//new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
//new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
//new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987/11/14"),DOJ = DateTime.Parse("2015/4/12"),City = "Pune"},
//new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1990/6/3"),DOJ = DateTime.Parse("2016/2/2"),City = "Pune"},
//new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1991/3/8"),DOJ = DateTime.Parse("2016/2/2"),City = "Mumbai"},
//new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("1998/11/7"),DOJ = DateTime.Parse("2014/8/8"),City = "Chennai"},
//new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("1989/12/2"),DOJ = DateTime.Parse("2015/6/1"),City = "Mumbai"},
//new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("1993/11/11"),DOJ = DateTime.Parse("2014/11/6"),City = "Chennai"},
//new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("1992/8/12"),DOJ = DateTime.Parse("2014/12/3"),City = "Chennai"},
//new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("1991/4/12"),DOJ = DateTime.Parse("2016/1/2"),City = "Pune"},


new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"}
};
        
            public static void displayAll()
            {
                var result = from Employee in empList select Employee;
                foreach (var obj in result)
                {
                    Console.WriteLine(obj.EmployeeID + " " +obj.FirstName + " "+obj.LastName + " " +obj.Title+" "+obj.DOB+" "+obj.DOJ+" "+obj.City);
                }
            }
            public static void notMubai()
            {
                var r = from emp in empList where emp.City != "Mumbai" select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void display()
            {
                var r = from emp in empList where emp.Title == "AsstManager" select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void lastName()
            {
                var r = from emp in empList where emp.LastName.StartsWith("S") select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void doj()
            {
                var r = from emp in empList where emp.DOJ < DateTime.Parse("1/1/2015") select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void dob()
            {
                var r = from emp in empList where emp.DOB > DateTime.Parse("1/1/1990") select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void designation()
            {
                var r = from emp in empList where emp.Title == "Consultant" || emp.Title == "Associate" select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }
            }
            public static void numOfemployee()
            {
                var result = from Employee in empList select Employee;
                Console.WriteLine(result.Count());
            }
            public static void Chennai()
                {

                var r = from emp in empList where emp.City == "Chennai"  select emp;
                foreach (var obj in r)
                {
                    Console.WriteLine(obj.EmployeeID + " " + obj.FirstName + " " + obj.LastName + " " + obj.Title + " " + obj.DOB + " " + obj.DOJ + " " + obj.City);
                }

            }
            public static void highestID()
            {
                var result = (from Employee in empList select Employee.EmployeeID).Max();
               
                Console.WriteLine(result);
            }
            public static void numOFEmpdoj()
            {
                var r = from emp in empList where emp.DOJ > DateTime.Parse("1/1/2015") select emp;
                Console.WriteLine(r.Count());

            }
            public static void noOfnonAssosiate()
            {
                var r = from emp in empList where emp.Title !=  "Associate" select emp;
                Console.WriteLine(r.Count());
            }

            public static void basedOnCity()
            {
                var result = from emp in empList group emp by emp.City into emp select emp;
                Console.WriteLine("Total no of Employee Details based on City is : " + result.Count());
            }
            public static void basedOnCityandTitle()
            {
                var result = from emp in empList group emp by new { emp.City, emp.Title } into emp select emp;
                Console.WriteLine("Total no of Employee Details based on City and Title is : " + result.Count());
            }
            public static void empYoungest()
            {
                var result = (from e in empList select e.DOB).Max();
                Console.WriteLine(" Employee Who is Youngest is : " + result);
            }

            public static void Main(string[] args)
          {
                try
                {
                    //displayAll();
                    //notMubai();
                    //display();

                    //doj();
                    //dob();
                    //designation();
                    //numOfemployee();
                    //Chennai();
                    //highestID();
                    //numOFEmpdoj();
                    //noOfnonAssosiate();
                    //basedOnCity();
                    //basedOnCityandTitle();
                    //empYoungest();
                   
                        Program p = new Program();

                        p.show(2, 3, 8);

                        int[] a = { 2, 90, 78, 45 };

                        Console.WriteLine("example of array");

                        Console.WriteLine("elements added are");

                        p.show(a);

                        Console.ReadLine();

                    }

                    public void show(params int[] b)

                    {

                        foreach (int i in b)

                        {

                            Console.WriteLine("ARRAY IS HAVING:{0}", i);

                        }

                    }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadKey();
          
          }
        }
    }
}
